enum UserRole { owner, manager, cashier, staff }
