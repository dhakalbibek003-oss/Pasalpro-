class Shop {
  final String id;
  final String shopCode;
  final String name;
  final String ownerUserId;
  final String? phone;
  final String? address;
  const Shop({
    required this.id,
    required this.shopCode,
    required this.name,
    required this.ownerUserId,
    this.phone,
    this.address,
  });
}
