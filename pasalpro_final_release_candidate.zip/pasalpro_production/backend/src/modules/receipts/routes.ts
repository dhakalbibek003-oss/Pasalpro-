import { Router } from 'express';
import { authRequired, AuthRequest } from '../../common/auth';
import { pool } from '../../db/db';
export const receiptsRouter = Router();
receiptsRouter.use(authRequired);
receiptsRouter.get('/:shopId/:saleId', async (req: AuthRequest, res) => {
  const { shopId, saleId } = req.params;
  const access = await pool.query(`SELECT 1 FROM shop_members WHERE shop_id=$1 AND user_id=$2 AND status='ACTIVE'`, [shopId, req.user!.id]);
  if (!access.rowCount) return res.status(403).json({ error: 'shop_access_required' });
  const sale = await pool.query(`SELECT s.id,s.created_at,s.subtotal,s.paid_amount,s.credit_amount,s.status,c.name customer_name,c.phone customer_phone,sh.name shop_name,sh.phone shop_phone,sh.address shop_address,sh.shop_code FROM sales s JOIN shops sh ON sh.id=s.shop_id LEFT JOIN customers c ON c.id=s.customer_id WHERE s.id=$1 AND s.shop_id=$2`, [saleId, shopId]);
  if (!sale.rowCount) return res.status(404).json({ error: 'sale_not_found' });
  const items = await pool.query(`SELECT product_name,qty,unit_price,line_total FROM sale_items WHERE sale_id=$1 ORDER BY id`, [saleId]);
  res.json({ receipt: { ...sale.rows[0], items: items.rows } });
});
