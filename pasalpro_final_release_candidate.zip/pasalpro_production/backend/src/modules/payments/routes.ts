import { Router } from 'express';
import { authRequired, AuthRequest } from '../../common/auth';
import { pool, withTransaction } from '../../db/db';

export const paymentsRouter = Router();
paymentsRouter.use(authRequired);

async function member(req: AuthRequest, shopId: string) {
  const r = await pool.query(`SELECT role FROM shop_members WHERE shop_id=$1 AND user_id=$2 AND status='ACTIVE'`, [shopId, req.user!.id]);
  return r.rowCount ? r.rows[0].role : null;
}
function amount(v: unknown) { const n=Number(v); return Number.isFinite(n)&&n>0 ? Math.round(n*100)/100 : null; }

paymentsRouter.post('/:shopId/intents', async (req: AuthRequest,res,next) => {
  try {
    const shopId=String(req.params.shopId); if(!await member(req,shopId)) return res.status(403).json({error:'shop_access_required'});
    const customerId=String(req.body?.customerId??''); const value=amount(req.body?.amount); const provider=String(req.body?.provider??'').toUpperCase(); const key=String(req.body?.idempotencyKey??'').trim();
    if(!customerId||value===null||!['ESEWA','KHALTI','BANK','CASH'].includes(provider)||!key) return res.status(400).json({error:'invalid_payment_intent'});
    const r=await pool.query(`INSERT INTO payment_intents(shop_id,customer_id,amount,provider,idempotency_key) VALUES($1,$2,$3,$4,$5) ON CONFLICT(shop_id,idempotency_key) DO UPDATE SET idempotency_key=EXCLUDED.idempotency_key RETURNING *`,[shopId,customerId,value,provider,key]);
    res.status(201).json({intent:r.rows[0], verificationRequired:provider!=='CASH'});
  } catch(e){next(e);}
});

// Provider webhooks must be called only by the verified provider adapter in production.
paymentsRouter.post('/:shopId/intents/:intentId/verify', async (req: AuthRequest,res,next) => {
  try {
    const shopId=String(req.params.shopId); if(!await member(req,shopId)) return res.status(403).json({error:'shop_access_required'});
    const result=await withTransaction(async c=>{
      const p=await c.query(`SELECT * FROM payment_intents WHERE id=$1 AND shop_id=$2 FOR UPDATE`,[req.params.intentId,shopId]); if(!p.rowCount) throw Object.assign(new Error('payment_intent_not_found'),{status:404}); const intent=p.rows[0];
      if(intent.status==='VERIFIED') return intent;
      // Development/admin verification hook. Replace with provider signature validation before production.
      if(String(req.body?.providerReference??'').trim()==='') throw Object.assign(new Error('provider_reference_required'),{status:400});
      const updated=(await c.query(`UPDATE payment_intents SET status='VERIFIED',provider_reference=$1,verified_at=now() WHERE id=$2 RETURNING *`,[String(req.body.providerReference),intent.id])).rows[0];
      const cust=await c.query(`SELECT id FROM customers WHERE id=$1 AND shop_id=$2`,[intent.customer_id,shopId]);
      if(cust.rowCount) {
        await c.query(`INSERT INTO khata_entries(shop_id,customer_id,type,amount,note,created_by) VALUES($1,$2,'PAYMENT',$3,$4,$5)`,[shopId,intent.customer_id,intent.amount,`${intent.provider} payment ${intent.id}`,req.user!.id]);
        await c.query(`INSERT INTO notifications(shop_id,customer_id,type,title,body) VALUES($1,$2,'PAYMENT_RECEIVED','Payment received',$3)`,[shopId,intent.customer_id,`Rs. ${intent.amount} payment verified.`]);
      }
      return updated;
    });
    res.json({intent:result,status:result.status});
  } catch(e){next(e);}
});

paymentsRouter.get('/:shopId/intents/:intentId', async (req: AuthRequest,res,next)=>{try{const shopId=String(req.params.shopId);if(!await member(req,shopId))return res.status(403).json({error:'shop_access_required'});const r=await pool.query(`SELECT * FROM payment_intents WHERE id=$1 AND shop_id=$2`,[req.params.intentId,shopId]);if(!r.rowCount)return res.status(404).json({error:'payment_intent_not_found'});res.json({intent:r.rows[0]});}catch(e){next(e);}});
