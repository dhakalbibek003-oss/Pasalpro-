export type PaymentProvider = 'ESEWA' | 'KHALTI';

export type PaymentVerification = {
  verified: boolean;
  providerReference: string;
  amount?: number;
  raw?: unknown;
};

/** Production adapter contract. Implement one adapter per provider and verify signatures server-side. */
export interface PaymentProviderAdapter {
  readonly provider: PaymentProvider;
  verify(input: { intentId: string; providerReference: string; amount: number; payload: unknown }): Promise<PaymentVerification>;
}
