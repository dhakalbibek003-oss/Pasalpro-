import { Router } from 'express';
import { authRequired, AuthRequest } from '../../common/auth';
import { pool } from '../../db/db';

export const notificationsRouter = Router();
notificationsRouter.use(authRequired);

notificationsRouter.get('/:shopId', async (req: AuthRequest, res, next) => {
  try {
    const shopId = String(req.params.shopId);
    const member = await pool.query(`SELECT 1 FROM shop_members WHERE shop_id=$1 AND user_id=$2 AND status='ACTIVE'`, [shopId, req.user!.id]);
    if (!member.rowCount) return res.status(403).json({ error: 'shop_access_required' });
    const limit = Math.min(Math.max(Number(req.query.limit ?? 50), 1), 100);
    const rows = await pool.query(`SELECT id,type,title,body,read_at,created_at FROM notifications WHERE shop_id=$1 ORDER BY created_at DESC LIMIT $2`, [shopId, limit]);
    res.json({ notifications: rows.rows });
  } catch (e) { next(e); }
});

notificationsRouter.post('/:shopId/:notificationId/read', async (req: AuthRequest, res, next) => {
  try {
    const shopId = String(req.params.shopId);
    const member = await pool.query(`SELECT 1 FROM shop_members WHERE shop_id=$1 AND user_id=$2 AND status='ACTIVE'`, [shopId, req.user!.id]);
    if (!member.rowCount) return res.status(403).json({ error: 'shop_access_required' });
    const r = await pool.query(`UPDATE notifications SET read_at=COALESCE(read_at,now()) WHERE id=$1 AND shop_id=$2 RETURNING id,read_at`, [req.params.notificationId, shopId]);
    if (!r.rowCount) return res.status(404).json({ error: 'notification_not_found' });
    res.json({ notification: r.rows[0] });
  } catch (e) { next(e); }
});
