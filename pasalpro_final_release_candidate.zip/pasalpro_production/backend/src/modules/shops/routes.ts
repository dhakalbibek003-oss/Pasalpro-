import { Router } from 'express';
import { generateShopCode } from '../../common/shop_code';
import { authRequired, AuthRequest, randomToken, hashTokenValue } from '../../common/auth';
import { withTransaction, pool } from '../../db/db';

export const shopsRouter = Router();

shopsRouter.get('/mine', authRequired, async (req: AuthRequest, res) => {
  const result = await pool.query(
    `SELECT s.id,s.shop_code,s.name,s.phone,s.address,s.latitude,s.longitude,s.logo_url,m.role
     FROM shops s JOIN shop_members m ON m.shop_id=s.id
     WHERE m.user_id=$1 AND m.status='ACTIVE' ORDER BY s.created_at DESC`, [req.user!.id]);
  res.json({ shops: result.rows });
});

shopsRouter.post('/', authRequired, async (req: AuthRequest, res) => {
  const name = String(req.body?.name ?? '').trim();
  const ownerName = String(req.body?.ownerName ?? '').trim();
  const phone = String(req.body?.phone ?? req.user!.phone).trim();
  const address = String(req.body?.address ?? '').trim() || null;
  const latitude = req.body?.latitude == null ? null : Number(req.body.latitude);
  const longitude = req.body?.longitude == null ? null : Number(req.body.longitude);
  if (!name || !ownerName) return res.status(400).json({ error: 'name_owner_required' });
  if ((latitude !== null && !Number.isFinite(latitude)) || (longitude !== null && !Number.isFinite(longitude))) {
    return res.status(400).json({ error: 'invalid_location' });
  }

  const created = await withTransaction(async (client) => {
    await client.query(`UPDATE users SET display_name=$1, updated_at=now() WHERE id=$2`, [ownerName, req.user!.id]);
    let shopCode = generateShopCode();
    for (let i=0;i<5;i++) {
      const exists = await client.query('SELECT 1 FROM shops WHERE shop_code=$1', [shopCode]);
      if (!exists.rowCount) break;
      shopCode = generateShopCode();
    }
    const shop = (await client.query(
      `INSERT INTO shops (shop_code,name,owner_user_id,phone,address,latitude,longitude)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id,shop_code,name,phone,address,latitude,longitude`,
      [shopCode,name,req.user!.id,phone,address,latitude,longitude])).rows[0];
    await client.query(`INSERT INTO shop_members(shop_id,user_id,role) VALUES ($1,$2,'OWNER')`, [shop.id, req.user!.id]);
    await client.query(`INSERT INTO audit_logs(shop_id,user_id,action,entity_type,entity_id) VALUES ($1,$2,'SHOP_CREATED','shop',$1)`, [shop.id, req.user!.id]);
    const qrRaw = randomToken();
    await client.query(`INSERT INTO shop_qr_tokens(shop_id,token_hash,expires_at) VALUES ($1,$2,now()+interval '24 hours')`, [shop.id,hashTokenValue(qrRaw)]);
    return { shop, qrPayload: `pasalpro://shop/connect?shop=${shop.shop_code}&token=${qrRaw}` };
  });
  res.status(201).json({ ok:true, ...created });
});
