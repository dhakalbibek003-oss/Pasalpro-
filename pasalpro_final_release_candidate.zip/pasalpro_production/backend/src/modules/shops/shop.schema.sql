CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS shops (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  shop_code VARCHAR(16) NOT NULL UNIQUE,
  name VARCHAR(160) NOT NULL,
  owner_user_id UUID NOT NULL,
  phone VARCHAR(32),
  address TEXT,
  latitude NUMERIC(10,7),
  longitude NUMERIC(10,7),
  logo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS shops_owner_user_idx ON shops(owner_user_id);
