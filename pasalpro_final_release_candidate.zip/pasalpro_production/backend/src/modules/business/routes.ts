import { Router } from 'express';
import { authRequired, AuthRequest } from '../../common/auth';
import { canManageShop, canRecordSale, Role } from '../../common/authz';
import { pool, withTransaction } from '../../db/db';

export const businessRouter = Router();
businessRouter.use(authRequired);

async function membership(req: AuthRequest, shopId: string) {
  const r = await pool.query(`SELECT role FROM shop_members WHERE shop_id=$1 AND user_id=$2 AND status='ACTIVE'`, [shopId, req.user!.id]);
  return r.rowCount ? r.rows[0].role as Role : null;
}
function money(v: unknown) { const n = Number(v); return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : null; }
function qty(v: unknown) { const n = Number(v); return Number.isFinite(n) && n > 0 ? Math.round(n * 1000) / 1000 : null; }

businessRouter.get('/:shopId/summary', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId); if(!await membership(req,shopId)) return res.status(403).json({error:'shop_access_required'});
  const [sales, customers, stock] = await Promise.all([
    pool.query(`SELECT COALESCE(SUM(subtotal),0) total_sales, COUNT(*) sales_count FROM sales WHERE shop_id=$1 AND created_at >= current_date`,[shopId]),
    pool.query(`SELECT COUNT(*) customer_count, COALESCE(SUM(x.balance),0) total_khata FROM (SELECT c.id, COALESCE(SUM(CASE WHEN k.type='CREDIT' THEN k.amount WHEN k.type IN ('PAYMENT','ADJUSTMENT') THEN -k.amount ELSE 0 END),0) balance FROM customers c LEFT JOIN khata_entries k ON k.customer_id=c.id WHERE c.shop_id=$1 GROUP BY c.id) x`,[shopId]),
    pool.query(`SELECT COUNT(*) low_stock_count FROM products WHERE shop_id=$1 AND active=true AND stock_qty <= low_stock_threshold`,[shopId])
  ]);
  res.json({salesToday:sales.rows[0], customers:customers.rows[0], stock:stock.rows[0]});
});

businessRouter.get('/:shopId/customers', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId); if(!await membership(req,shopId)) return res.status(403).json({error:'shop_access_required'});
  const r=await pool.query(`SELECT c.id,c.name,c.phone,c.address,COALESCE(SUM(CASE WHEN k.type='CREDIT' THEN k.amount WHEN k.type IN ('PAYMENT','ADJUSTMENT') THEN -k.amount ELSE 0 END),0) balance FROM customers c LEFT JOIN khata_entries k ON k.customer_id=c.id WHERE c.shop_id=$1 GROUP BY c.id ORDER BY c.name`,[shopId]);
  res.json({customers:r.rows});
});

businessRouter.post('/:shopId/customers', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId); const role=await membership(req,shopId); if(!role||!canManageShop(role)) return res.status(403).json({error:'manager_required'});
  const name=String(req.body?.name??'').trim(); const phone=String(req.body?.phone??'').trim()||null; const address=String(req.body?.address??'').trim()||null;
  if(!name) return res.status(400).json({error:'customer_name_required'});
  try { const r=await pool.query(`INSERT INTO customers(shop_id,name,phone,address) VALUES($1,$2,$3,$4) RETURNING *`,[shopId,name,phone,address]); res.status(201).json({customer:r.rows[0]}); }
  catch(e:any){ if(e.code==='23505') return res.status(409).json({error:'customer_phone_exists'}); throw e; }
});

businessRouter.get('/:shopId/products', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId); if(!await membership(req,shopId)) return res.status(403).json({error:'shop_access_required'});
  const r=await pool.query(`SELECT * FROM products WHERE shop_id=$1 AND active=true ORDER BY name`,[shopId]); res.json({products:r.rows});
});

businessRouter.post('/:shopId/products', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId); const role=await membership(req,shopId); if(!role||!canManageShop(role)) return res.status(403).json({error:'manager_required'});
  const name=String(req.body?.name??'').trim(); const unit=String(req.body?.unit??'pcs').trim().slice(0,32); const sku=String(req.body?.sku??'').trim()||null;
  const sale=money(req.body?.salePrice), cost=money(req.body?.costPrice??0), opening=Number(req.body?.openingQty??0), low=money(req.body?.lowStockThreshold??0);
  if(!name||sale===null||cost===null||!Number.isFinite(opening)||opening<0||low===null) return res.status(400).json({error:'invalid_product_fields'});
  try { const p=await withTransaction(async c=>{ const r=(await c.query(`INSERT INTO products(shop_id,sku,name,unit,sale_price,cost_price,stock_qty,low_stock_threshold) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,[shopId,sku,name,unit,sale,cost,opening,low])).rows[0]; if(opening>0) await c.query(`INSERT INTO stock_movements(shop_id,product_id,type,qty,created_by) VALUES($1,$2,'OPENING',$3,$4)`,[shopId,r.id,opening,req.user!.id]); return r; }); res.status(201).json({product:p}); }
  catch(e:any){ if(e.code==='23505') return res.status(409).json({error:'product_sku_exists'}); throw e; }
});

businessRouter.post('/:shopId/products/:productId/stock', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId), productId=String(req.params.productId); const role=await membership(req,shopId); if(!role||!canManageShop(role)) return res.status(403).json({error:'manager_required'});
  const amount=qty(req.body?.qty), type=String(req.body?.type??'PURCHASE'); if(amount===null||!['PURCHASE','ADJUSTMENT'].includes(type)) return res.status(400).json({error:'invalid_stock_movement'});
  const product=await withTransaction(async c=>{ const r=await c.query(`UPDATE products SET stock_qty=stock_qty+$1,updated_at=now() WHERE id=$2 AND shop_id=$3 RETURNING *`,[amount,productId,shopId]); if(!r.rowCount) throw Object.assign(new Error('product_not_found'),{status:404}); await c.query(`INSERT INTO stock_movements(shop_id,product_id,type,qty,created_by,note) VALUES($1,$2,$3,$4,$5,$6)`,[shopId,productId,type,amount,req.user!.id,String(req.body?.note??'').trim()||null]); return r.rows[0]; }); res.json({product});
});

businessRouter.get('/:shopId/customers/:customerId/khata', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId), customerId=String(req.params.customerId); if(!await membership(req,shopId)) return res.status(403).json({error:'shop_access_required'});
  const customer=await pool.query(`SELECT id,name,phone,address FROM customers WHERE id=$1 AND shop_id=$2`,[customerId,shopId]); if(!customer.rowCount) return res.status(404).json({error:'customer_not_found'});
  const entries=await pool.query(`SELECT id,type,amount,note,sale_id,created_at FROM khata_entries WHERE customer_id=$1 AND shop_id=$2 ORDER BY created_at DESC`,[customerId,shopId]);
  const balance=entries.rows.reduce((s:number,e:any)=>s+(e.type==='CREDIT'?Number(e.amount):-Number(e.amount)),0);
  res.json({customer:customer.rows[0],balance:Math.max(0,Math.round(balance*100)/100),entries:entries.rows});
});

businessRouter.post('/:shopId/customers/:customerId/payment', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId), customerId=String(req.params.customerId); const role=await membership(req,shopId); if(!role||!canRecordSale(role)) return res.status(403).json({error:'sale_access_required'});
  const amount=money(req.body?.amount); if(amount===null||amount<=0) return res.status(400).json({error:'invalid_payment_amount'});
  const result=await withTransaction(async c=>{ const cust=await c.query(`SELECT id FROM customers WHERE id=$1 AND shop_id=$2`,[customerId,shopId]); if(!cust.rowCount) throw Object.assign(new Error('customer_not_found'),{status:404}); const b=await c.query(`SELECT COALESCE(SUM(CASE WHEN type='CREDIT' THEN amount ELSE -amount END),0) balance FROM khata_entries WHERE customer_id=$1`,[customerId]); const balance=Number(b.rows[0].balance); if(amount>balance+0.005) throw Object.assign(new Error('payment_exceeds_balance'),{status:400}); const e=(await c.query(`INSERT INTO khata_entries(shop_id,customer_id,type,amount,note,created_by) VALUES($1,$2,'PAYMENT',$3,$4,$5) RETURNING *`,[shopId,customerId,amount,String(req.body?.note??'').trim()||'Payment',req.user!.id])).rows[0]; return {entry:e,balance:Math.max(0,Math.round((balance-amount)*100)/100)}; }); res.status(201).json(result);
});

businessRouter.post('/:shopId/sales', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId), role=await membership(req,shopId); if(!role||!canRecordSale(role)) return res.status(403).json({error:'sale_access_required'});
  const customerId=req.body?.customerId?String(req.body.customerId):null, paid=money(req.body?.paidAmount??0); const items=Array.isArray(req.body?.items)?req.body.items:[];
  if(paid===null||!items.length) return res.status(400).json({error:'items_and_paid_amount_required'});
  const result=await withTransaction(async c=>{
    if(customerId){const cr=await c.query(`SELECT id FROM customers WHERE id=$1 AND shop_id=$2`,[customerId,shopId]);if(!cr.rowCount)throw Object.assign(new Error('customer_not_found'),{status:404});}
    let subtotal=0; const normalized:any[]=[];
    for(const item of items){ const productId=String(item.productId??''); const q=qty(item.qty); if(!productId||q===null) throw Object.assign(new Error('invalid_sale_item'),{status:400}); const pr=await c.query(`SELECT id,name,sale_price,stock_qty FROM products WHERE id=$1 AND shop_id=$2 AND active=true FOR UPDATE`,[productId,shopId]); if(!pr.rowCount) throw Object.assign(new Error('product_not_found'),{status:404}); const p=pr.rows[0]; if(Number(p.stock_qty)<q) throw Object.assign(new Error('insufficient_stock'),{status:400}); const unit=money(item.unitPrice??p.sale_price); if(unit===null) throw Object.assign(new Error('invalid_unit_price'),{status:400}); const line=Math.round(q*unit*100)/100; subtotal+=line; normalized.push({p,q,unit,line}); }
    subtotal=Math.round(subtotal*100)/100; if(paid>subtotal+0.005) throw Object.assign(new Error('paid_exceeds_total'),{status:400}); const credit=Math.round((subtotal-paid)*100)/100; if(credit>0&&!customerId) throw Object.assign(new Error('customer_required_for_credit'),{status:400});
    const sale=(await c.query(`INSERT INTO sales(shop_id,customer_id,created_by,subtotal,paid_amount,credit_amount) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,[shopId,customerId,req.user!.id,subtotal,paid,credit])).rows[0];
    for(const x of normalized){ await c.query(`INSERT INTO sale_items(sale_id,product_id,product_name,qty,unit_price,line_total) VALUES($1,$2,$3,$4,$5,$6)`,[sale.id,x.p.id,x.p.name,x.q,x.unit,x.line]); await c.query(`UPDATE products SET stock_qty=stock_qty-$1,updated_at=now() WHERE id=$2`,[x.q,x.p.id]); await c.query(`INSERT INTO stock_movements(shop_id,product_id,type,qty,reference_id,created_by) VALUES($1,$2,'SALE',$3,$4,$5)`,[shopId,x.p.id,-x.q,sale.id,req.user!.id]); }
    if(credit>0) await c.query(`INSERT INTO khata_entries(shop_id,customer_id,sale_id,type,amount,note,created_by) VALUES($1,$2,$3,'CREDIT',$4,'Sale on credit',$5)`,[shopId,customerId,sale.id,credit,req.user!.id]);
    await c.query(`INSERT INTO audit_logs(shop_id,user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'SALE_COMPLETED','sale',$3,$4)`,[shopId,req.user!.id,sale.id,JSON.stringify({subtotal,paid,credit})]);
    return sale;
  });
  res.status(201).json({sale:result});
});

businessRouter.get('/:shopId/sales', async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId); if(!await membership(req,shopId)) return res.status(403).json({error:'shop_access_required'});
  const limit=Math.min(Math.max(Number(req.query.limit??50),1),100);
  const r=await pool.query(`SELECT s.id,s.created_at,s.subtotal,s.paid_amount,s.credit_amount,s.status,c.name customer_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.shop_id=$1 ORDER BY s.created_at DESC LIMIT $2`,[shopId,limit]);
  res.json({sales:r.rows});
});
