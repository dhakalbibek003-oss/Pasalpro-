import { Router } from 'express';
import { issueOtp, verifyOtp } from './otp.service';
import { pool } from '../../db/db';
import { createSession } from '../../common/auth';

export const authRouter = Router();

function normalizePhone(value: string) {
  const compact = value.replace(/\s|-/g, '');
  if (/^98\d{8}$/.test(compact) || /^97\d{8}$/.test(compact)) return `+977${compact}`;
  if (/^\+9779[78]\d{8}$/.test(compact)) return compact;
  if (/^9779[78]\d{8}$/.test(compact)) return `+${compact}`;
  return null;
}

authRouter.post('/otp/request', async (req, res) => {
  const phone = normalizePhone(String(req.body?.phone ?? ''));
  if (!phone) return res.status(400).json({ error: 'invalid_nepal_phone' });
  const result = issueOtp(phone);
  return res.status(202).json({ ok: true, requestId: result.requestId,
    ...(process.env.NODE_ENV !== 'production' ? { developmentOtp: result.otpForDevelopment } : {}) });
});

authRouter.post('/otp/verify', async (req, res) => {
  const phone = normalizePhone(String(req.body?.phone ?? ''));
  const otp = String(req.body?.otp ?? '').trim();
  if (!phone || !verifyOtp(phone, otp)) return res.status(401).json({ error: 'invalid_or_expired_otp' });

  const result = await pool.query(
    `INSERT INTO users (phone) VALUES ($1)
     ON CONFLICT (phone) DO UPDATE SET updated_at=now()
     RETURNING id, phone, display_name`, [phone]);
  const user = result.rows[0];
  const session = await createSession(user.id);
  return res.json({ ok: true, user, session: { accessToken: session.token, expiresAt: session.expiresAt }, next: 'shop_or_dashboard' });
});


authRouter.post('/logout', async (req, res) => {
  const header = String(req.headers.authorization ?? '');
  if (!header.startsWith('Bearer ')) return res.status(204).send();
  const raw = header.slice(7).trim();
  const { hashTokenValue } = await import('../../common/auth');
  await pool.query(`UPDATE sessions SET revoked_at=now() WHERE token_hash=$1 AND revoked_at IS NULL`, [hashTokenValue(raw)]);
  return res.status(204).send();
});
