import { randomInt, randomUUID } from 'node:crypto';

type OtpRecord = { hash: string; expiresAt: number; attempts: number };

const records = new Map<string, OtpRecord>();

// Development starter only. Production must use a managed OTP/SMS provider,
// hashed OTP storage, rate limits, and persistent session storage.
export function issueOtp(phone: string) {
  const otp = String(randomInt(100000, 1000000));
  records.set(phone, {
    hash: otp, // TODO: replace with a password-grade hash.
    expiresAt: Date.now() + 5 * 60_000,
    attempts: 0,
  });
  return { requestId: randomUUID(), otpForDevelopment: otp };
}

export function verifyOtp(phone: string, otp: string) {
  const record = records.get(phone);
  if (!record || Date.now() > record.expiresAt || record.attempts >= 5) return false;
  record.attempts++;
  const ok = record.hash === otp;
  if (ok) records.delete(phone);
  return ok;
}
