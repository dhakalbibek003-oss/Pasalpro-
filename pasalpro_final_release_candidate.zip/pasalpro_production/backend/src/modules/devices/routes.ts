import { Router } from 'express';
import { authRequired, AuthRequest, randomToken, hashTokenValue, createSession } from '../../common/auth';
import { pool, withTransaction } from '../../db/db';

export const devicesRouter = Router();

async function owner(req: AuthRequest, shopId: string) {
  const r = await pool.query(`SELECT 1 FROM shop_members WHERE shop_id=$1 AND user_id=$2 AND role='OWNER' AND status='ACTIVE'`, [shopId,req.user!.id]);
  return !!r.rowCount;
}

devicesRouter.post('/:shopId/invitations', authRequired, async (req: AuthRequest, res) => {
  const shopId = String(req.params.shopId);
  if (!(await owner(req,shopId))) return res.status(403).json({error:'owner_required'});
  const raw = randomToken();
  await pool.query(`INSERT INTO device_invitations(shop_id,token_hash,expires_at,created_by) VALUES($1,$2,now()+interval '10 minutes',$3)`, [shopId,hashTokenValue(raw),req.user!.id]);
  await pool.query(`INSERT INTO audit_logs(shop_id,user_id,action,entity_type) VALUES($1,$2,'DEVICE_INVITATION_CREATED','device_invitation')`, [shopId,req.user!.id]);
  res.status(201).json({ok:true, expiresInSeconds:600, invitation:`pasalpro://device/join?shopId=${shopId}&token=${raw}`});
});

devicesRouter.post('/:shopId/join', authRequired, async (req: AuthRequest, res) => {
  const shopId=String(req.params.shopId), token=String(req.body?.token??'');
  const deviceName=String(req.body?.deviceName??'My Device').trim().slice(0,160);
  const platform=String(req.body?.platform??'unknown').trim().slice(0,32);
  if(!token) return res.status(400).json({error:'invitation_token_required'});
  const inv=await pool.query(`SELECT id FROM device_invitations WHERE shop_id=$1 AND token_hash=$2 AND used_at IS NULL AND expires_at>now()`,[shopId,hashTokenValue(token)]);
  if(!inv.rowCount) return res.status(400).json({error:'invalid_or_expired_invitation'});
  const device=await withTransaction(async client=>{
    const d=(await client.query(`INSERT INTO devices(shop_id,user_id,device_name,platform) VALUES($1,$2,$3,$4) RETURNING id,device_name,platform,created_at`,[shopId,req.user!.id,deviceName,platform])).rows[0];
    await client.query(`UPDATE device_invitations SET used_at=now() WHERE id=$1`,[inv.rows[0].id]);
    await client.query(`INSERT INTO audit_logs(shop_id,user_id,action,entity_type,entity_id) VALUES($1,$2,'DEVICE_JOIN_REQUESTED','device',$3)`,[shopId,req.user!.id,d.id]);
    return d;
  });
  res.status(201).json({ok:true,status:'PENDING_OWNER_APPROVAL',device});
});

devicesRouter.get('/:shopId', authRequired, async (req: AuthRequest,res)=>{
  const shopId=String(req.params.shopId);
  if(!(await owner(req,shopId))) return res.status(403).json({error:'owner_required'});
  const r=await pool.query(`SELECT id,user_id,device_name,platform,approved_at,revoked_at,created_at FROM devices WHERE shop_id=$1 ORDER BY created_at DESC`,[shopId]);
  res.json({devices:r.rows});
});

devicesRouter.post('/:shopId/:deviceId/approve', authRequired, async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId), deviceId=String(req.params.deviceId);
  if(!(await owner(req,shopId))) return res.status(403).json({error:'owner_required'});
  const r=await pool.query(`UPDATE devices SET approved_at=COALESCE(approved_at,now()),revoked_at=NULL WHERE id=$1 AND shop_id=$2 RETURNING id,user_id`,[deviceId,shopId]);
  if(!r.rowCount) return res.status(404).json({error:'device_not_found'});
  await pool.query(`INSERT INTO audit_logs(shop_id,user_id,action,entity_type,entity_id) VALUES($1,$2,'DEVICE_APPROVED','device',$3)`,[shopId,req.user!.id,deviceId]);
  res.json({ok:true,status:'APPROVED',deviceId});
});

devicesRouter.post('/:shopId/:deviceId/revoke', authRequired, async (req: AuthRequest,res) => {
  const shopId=String(req.params.shopId), deviceId=String(req.params.deviceId);
  if(!(await owner(req,shopId))) return res.status(403).json({error:'owner_required'});
  const r=await pool.query(`UPDATE devices SET revoked_at=now() WHERE id=$1 AND shop_id=$2 RETURNING session_id`,[deviceId,shopId]);
  if(!r.rowCount) return res.status(404).json({error:'device_not_found'});
  if(r.rows[0].session_id) await pool.query(`UPDATE sessions SET revoked_at=now() WHERE id=$1`,[r.rows[0].session_id]);
  await pool.query(`INSERT INTO audit_logs(shop_id,user_id,action,entity_type,entity_id) VALUES($1,$2,'DEVICE_REVOKED','device',$3)`,[shopId,req.user!.id,deviceId]);
  res.json({ok:true,status:'REVOKED',deviceId});
});
