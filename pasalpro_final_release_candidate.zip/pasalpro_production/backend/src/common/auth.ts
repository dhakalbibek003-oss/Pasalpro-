import crypto from 'node:crypto';
import { Request, Response, NextFunction } from 'express';
import { pool } from '../db/db';

export type AuthUser = { id: string; phone: string; displayName: string | null };
export type AuthRequest = Request & { user?: AuthUser; sessionId?: string };

function hashToken(token: string) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export async function createSession(userId: string, deviceId?: string) {
  const raw = crypto.randomBytes(48).toString('base64url');
  const hash = hashToken(raw);
  const result = await pool.query(
    `INSERT INTO sessions (user_id, device_id, token_hash, expires_at)
     VALUES ($1,$2,$3,now()+interval '30 days')
     RETURNING id, expires_at`,
    [userId, deviceId ?? null, hash],
  );
  return { token: raw, sessionId: result.rows[0].id as string, expiresAt: result.rows[0].expires_at };
}

export async function authRequired(req: AuthRequest, res: Response, next: NextFunction) {
  const header = String(req.headers.authorization ?? '');
  if (!header.startsWith('Bearer ')) return res.status(401).json({ error: 'authentication_required' });
  const raw = header.slice(7).trim();
  if (!raw) return res.status(401).json({ error: 'authentication_required' });
  const result = await pool.query(
    `SELECT s.id AS session_id, u.id, u.phone, u.display_name
     FROM sessions s JOIN users u ON u.id=s.user_id
     WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at > now()`,
    [hashToken(raw)],
  );
  if (!result.rowCount) return res.status(401).json({ error: 'invalid_or_expired_session' });
  req.sessionId = result.rows[0].session_id;
  req.user = { id: result.rows[0].id, phone: result.rows[0].phone, displayName: result.rows[0].display_name };
  next();
}

export function randomToken() { return crypto.randomBytes(32).toString('base64url'); }
export function hashTokenValue(value: string) { return hashToken(value); }
