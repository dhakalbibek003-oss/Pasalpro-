export type Role = 'OWNER' | 'MANAGER' | 'CASHIER' | 'STAFF';

export function canManageShop(role: Role) {
  return role === 'OWNER' || role === 'MANAGER';
}

export function canManageDevices(role: Role) {
  return role === 'OWNER';
}

export function canRecordSale(role: Role) {
  return ['OWNER', 'MANAGER', 'CASHIER', 'STAFF'].includes(role);
}
