import express from 'express';
import crypto from 'node:crypto';
import { authRouter } from './modules/auth/routes';
import { shopsRouter } from './modules/shops/routes';
import { devicesRouter } from './modules/devices/routes';
import { businessRouter } from './modules/business/routes';
import { paymentsRouter } from './modules/payments/routes';
import { receiptsRouter } from './modules/receipts/routes';
import { notificationsRouter } from './modules/notifications/routes';

export const app = express();
app.disable('x-powered-by');
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','no-referrer');
  next();
});

const rateBuckets = new Map<string,{count:number; reset:number}>();
app.use((req,res,next)=>{
  if (req.path === '/health') return next();
  const key = `${req.ip}:${req.path}`;
  const now = Date.now();
  const current = rateBuckets.get(key);
  if (!current || current.reset < now) rateBuckets.set(key,{count:1,reset:now+60_000});
  else if (++current.count > 120) return res.status(429).json({error:'rate_limit_exceeded'});
  next();
});
app.use(express.json({ limit: '1mb' }));
app.get('/health', (_req,res)=>res.json({ok:true,service:'pasalpro-api'}));
app.use('/api/auth',authRouter);
app.use('/api/shops',shopsRouter);
app.use('/api/devices',devicesRouter);
app.use('/api/business',businessRouter);
app.use('/api/payments',paymentsRouter);
app.use('/api/receipts',receiptsRouter);
app.use('/api/notifications',notificationsRouter);
app.use((err:any,_req:any,res:any,_next:any)=>{
  console.error(err);
  const status = Number(err?.status);
  if (Number.isInteger(status) && status >= 400 && status < 500) return res.status(status).json({error: err.message || 'request_failed'});
  res.status(500).json({error:'internal_server_error'});
});
