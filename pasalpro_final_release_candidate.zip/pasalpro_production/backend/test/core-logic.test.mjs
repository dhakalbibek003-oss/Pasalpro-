import assert from 'node:assert/strict';

function balance(entries) {
  return Math.max(0, Math.round(entries.reduce((s, e) => s + (e.type === 'CREDIT' ? e.amount : -e.amount), 0) * 100) / 100);
}

assert.equal(balance([{type:'CREDIT',amount:500},{type:'PAYMENT',amount:200}]), 300);
assert.equal(Math.round(3 * 12.5 * 100) / 100, 37.5);
assert.ok(150 <= 200, 'stock must cover sale quantity');
console.log('PasalPro core logic tests: PASS');
