# PasalPro Production Starter

PasalPro is a Nepal-focused shop management system foundation for customers, Khata/credit, sales, stock, multi-device shop access and payments.

## Current milestone
Milestone 4 adds real PostgreSQL-backed Customer, Product/Stock, Sales and Khata API foundations.

## Backend
- Node.js + Express + TypeScript
- PostgreSQL
- Transactional sales and stock updates
- Role-based authorization
- Session token authentication foundation
- Audit logging

## Run
1. Set `DATABASE_URL` in `backend/.env`.
2. Install backend dependencies with `npm install`.
3. Run migrations with `npm run migrate`.
4. Start API with `npm run dev`.

## Important
This repository is still a production-development build, not a finished store-ready APK. Payment verification, SMS provider, customer portal, Flutter business screens, tests and release signing remain before production release.


## Milestone 5
Payment intent/verification foundation, notifications, and Flutter starter screens were added. See docs/MILESTONE-5.md.

## Current milestone
Milestone 6: responsive app shell + API client/session foundation.

## Milestone 7
Receipt retrieval and production-oriented database indexes have been added. See `docs/MILESTONE-7.md` and `docs/API-CONTRACT.md`.


## Milestone 9
Core authenticated Flutter flow, live shop selection, dashboard, customer/product management, and functional POS sale flow are now wired to the backend API. See `docs/MILESTONE-9.md`.

## Current status — Milestone 10
Core business flow, API integration foundation, payment/notification contracts, and release checklist are now consolidated. Production credentials/provider adapters, deployment, signing, and physical-device acceptance testing remain environment-specific release tasks.
