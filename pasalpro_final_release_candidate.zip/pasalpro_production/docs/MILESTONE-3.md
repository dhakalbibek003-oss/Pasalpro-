# PasalPro Milestone 3 — Real persistence + sessions + device approval

This milestone moves the API foundation from placeholders toward a real PostgreSQL-backed service.

## Added
- PostgreSQL pool and transaction helper.
- SQL migration runner: `npm run migrate`.
- Initial schema for users, shops, memberships, sessions, devices, QR/invitation tokens and audit logs.
- OTP verification now creates/updates a user and returns a 30-day opaque bearer session token.
- Auth middleware validates hashed session tokens server-side.
- Shop creation now uses the authenticated user instead of accepting owner identity from the client.
- Shop creation transaction creates the owner membership and a 24-hour QR token.
- `GET /api/shops/mine`.
- Device invitation creation (owner only), 10-minute one-time invitation token.
- Device join request and owner approve/revoke endpoints.
- Basic audit events for shop/device actions.
- `.env.example`.

## Still required before production
- Replace in-memory OTP with an SMS/OTP provider and hashed OTP storage.
- Add request rate limiting, abuse controls and CAPTCHA/risk checks where needed.
- Add refresh-token rotation/device-bound sessions and enforce device approval on every shop API operation.
- Add real QR rendering/scanning in Flutter.
- Add customer, product, stock, sales and Khata modules.
- Add payment gateway server integrations and webhook verification.
- Add notification service, backups, monitoring, tests and CI/CD.
- Configure production secrets and PostgreSQL with TLS/private networking.

## Local backend setup
1. Create PostgreSQL database.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`.
3. Run `npm install`.
4. Run `npm run migrate`.
5. Run `npm run dev`.

The current OTP implementation intentionally exposes a development OTP only when `NODE_ENV` is not `production`.
