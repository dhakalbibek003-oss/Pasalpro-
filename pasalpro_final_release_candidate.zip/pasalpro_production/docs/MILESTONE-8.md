# PasalPro Milestone 8

Live API integration foundation for the Flutter app.

## Added
- Central API service for shop/customer/product/sales/khata/payment/receipt calls.
- Session-aware API client with bearer token support.
- Live-data repositories for dashboard and business modules.
- Loading/error/empty states in app shell pages.
- Backend health endpoint and API contract notes.

## Important
This is still a development build. Production requires real OTP/SMS provider, persistent auth/session storage, HTTPS, PostgreSQL deployment, payment merchant credentials/KYC, tests, signing and release configuration.
