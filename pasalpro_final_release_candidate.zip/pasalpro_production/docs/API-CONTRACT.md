# PasalPro API contract (Milestone 7)

Base path: `/api`

## Auth
- `POST /auth/otp/request`
- `POST /auth/otp/verify`

## Business (Bearer session required)
- `GET /business/:shopId/summary`
- `GET/POST /business/:shopId/customers`
- `GET/POST /business/:shopId/products`
- `POST /business/:shopId/products/:productId/stock`
- `GET /business/:shopId/customers/:customerId/khata`
- `POST /business/:shopId/customers/:customerId/payment`
- `POST /business/:shopId/sales`

## Receipts
- `GET /receipts/:shopId/:saleId`

## Payments
Payment creation/finalization remains server-authoritative. A client must never mark an eSewa/Khalti payment as successful solely from a browser/app callback.
