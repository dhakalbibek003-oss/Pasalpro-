# Architecture

Every business record is scoped by `shop_id`.
Server authorization verifies authenticated membership and role before every read/write.

Roles:
OWNER, MANAGER, CASHIER, STAFF

Core entities:
users, shops, shop_members, devices, customers, products, sales, sale_items,
ledger_entries, payments, audit_logs.

The mobile app is not the financial source of truth.
