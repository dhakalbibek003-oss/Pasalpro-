# PasalPro Final Release Candidate

This milestone packages the current backend as a reproducible container stack and hardens the HTTP boundary.

## Included
- Dockerfile for the API
- Docker Compose for PostgreSQL + API
- Security response headers
- Basic per-IP/path rate limiting
- Correct propagation of business 4xx errors
- Session logout/revocation endpoint
- Production start command

## Before real production
1. Replace development OTP service with an SMS provider and persistent/hashed OTP storage.
2. Configure real payment credentials and server-to-server verification for eSewa/Khalti.
3. Put the API behind HTTPS/reverse proxy and managed secrets.
4. Configure PostgreSQL backups, monitoring and alerting.
5. Add FCM/APNs push credentials and notification workers.
6. Run Flutter release builds on Android/iOS and perform device testing.
7. Complete Play Store/App Store signing and privacy/legal materials.

## Local API stack
```bash
docker compose up --build
```
API health: `http://localhost:8080/health`
