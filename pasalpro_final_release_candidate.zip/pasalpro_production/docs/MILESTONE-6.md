# Milestone 6 — App shell + API client foundation

Added a responsive Flutter application shell with navigation for Dashboard, Sales, Khata/Customers, Stock, Payments and Receipts.

Added a reusable HTTP API client with bearer-token support and structured API errors, plus a session model for shop/role state.

The app is still a development build: authentication persistence, real API login, secure token storage, production payment SDKs, push notifications and release signing remain before a production APK.
