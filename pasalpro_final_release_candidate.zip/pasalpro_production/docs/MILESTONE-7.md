# PasalPro Milestone 7 — Live business data + receipt API

This milestone extends the existing production-oriented starter with:

- Receipt retrieval API for completed sales.
- Receipt data includes shop, customer, line items, paid amount and remaining credit.
- Additional database indexes for khata, audit logs and session cleanup.
- Receipt route is protected by the same shop-membership authorization used by business APIs.

## API

`GET /api/receipts/:shopId/:saleId`

Requires `Authorization: Bearer <session-token>` and an active shop membership.

## Next

The next implementation step is wiring the Flutter pages to these live endpoints, adding local secure session storage, loading states/error states, and a real POS checkout flow against the API. Payment-provider callbacks and production OTP/SMS remain deployment-stage integrations and must be verified with merchant credentials.
