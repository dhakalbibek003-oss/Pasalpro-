# PasalPro Milestone 5

Implemented:
- Payment-intent database with idempotency.
- Provider choices: eSewa, Khalti, Bank, Cash.
- Verified-payment flow that records a Khata payment only after server-side verification hook.
- Payment-received notification record.
- Flutter starter screens for Customers/Khata, Stock, Sales/POS, Payments and Receipts.
- Flutter pubspec foundation.

Important: the `/verify` endpoint is a development/admin hook. Before production it must be replaced or protected by real eSewa/Khalti webhook/signature verification and merchant credentials. Never trust a client-only payment success callback.
