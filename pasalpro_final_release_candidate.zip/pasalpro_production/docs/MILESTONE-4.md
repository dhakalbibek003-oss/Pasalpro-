# PasalPro Milestone 4 — Customer, Khata, Stock & Sales

Implemented backend foundation for daily shop operations: customers, products, stock movements, sales, automatic Khata credit, manual payment recording, dashboard summary, role checks, PostgreSQL transactions and audit logs.

API:
- GET /api/business/:shopId/summary
- GET/POST /api/business/:shopId/customers
- GET /api/business/:shopId/customers/:customerId/khata
- POST /api/business/:shopId/customers/:customerId/payment
- GET/POST /api/business/:shopId/products
- POST /api/business/:shopId/products/:productId/stock
- POST /api/business/:shopId/sales

Next: Flutter Customer/Product/Stock/POS/Khata/Receipt screens, then verified eSewa/Khalti payment flow and customer portal.
