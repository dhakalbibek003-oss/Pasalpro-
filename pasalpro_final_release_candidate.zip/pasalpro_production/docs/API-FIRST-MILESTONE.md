# First API milestone

POST /api/auth/otp/request
POST /api/auth/otp/verify
POST /api/shops
GET /api/shops/:shopId
POST /api/shops/:shopId/devices/request
POST /api/shops/:shopId/devices/:deviceId/approve
POST /api/shops/:shopId/devices/:deviceId/revoke

All financial mutations later must be idempotent, authorized server-side, and audited.
