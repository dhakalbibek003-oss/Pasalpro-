# PasalPro Milestone 10 — production finishing foundation

This milestone consolidates the remaining core work into one release-preparation step.

Included:
- Notification list/read API with shop membership authorization.
- Payment-provider adapter contract for server-side eSewa/Khalti verification.
- Core-logic smoke tests for Khata balance and sales calculations.
- Release checklist covering provider credentials, OTP/SMS, database backups, TLS, secrets, Android signing, and production testing.

Important: provider adapters and OTP delivery are intentionally contracts/placeholders until real merchant credentials and an SMS provider are configured. Never treat a client-side callback as proof of payment.
