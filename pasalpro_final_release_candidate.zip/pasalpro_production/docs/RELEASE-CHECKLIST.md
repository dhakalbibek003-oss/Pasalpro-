# Production release checklist

## Backend
- [ ] Set DATABASE_URL to managed PostgreSQL.
- [ ] Run migrations against a staging database first.
- [ ] Replace development OTP service with an SMS/OTP provider; hash OTPs and rate-limit requests.
- [ ] Implement eSewa/Khalti server-side provider adapters and signature/amount/reference validation.
- [ ] Store secrets only in environment/secret manager.
- [ ] Enable HTTPS/TLS and secure headers at the deployment edge.
- [ ] Configure database backups and restore testing.
- [ ] Add structured logs, monitoring, alerting, and audit retention.

## Flutter/Android
- [ ] Configure production API base URL.
- [ ] Add Android applicationId/package name and launcher icon.
- [ ] Create release signing key and keep it outside source control.
- [ ] Build and test release APK on physical devices.
- [ ] Build AAB for Play Store after acceptance testing.

## Acceptance tests
- [ ] Login/OTP and new-device approval.
- [ ] Create shop and connect another device.
- [ ] Create customer/product.
- [ ] Complete cash sale; verify stock decreases.
- [ ] Complete credit sale; verify Khata increases.
- [ ] Record Khata payment; verify balance decreases.
- [ ] Generate/share receipt.
- [ ] Verify payment only after provider-side confirmation.
- [ ] Verify role restrictions and audit logs.
- [ ] Test offline entry/sync behavior before enabling it in production.
