# Next steps after Milestone 4

1. Flutter UI: customer list/detail, product/stock, POS cart, Khata, receipt.
2. Customer-side account and shop connection by Shop ID/QR.
3. Payment gateway: eSewa/Khalti server verification + webhook/idempotency.
4. Notifications: payment received, low stock, Khata reminders.
5. Offline queue + sync conflict handling.
6. Automated API/unit/integration tests.
7. Android release configuration and signed APK/AAB build.
