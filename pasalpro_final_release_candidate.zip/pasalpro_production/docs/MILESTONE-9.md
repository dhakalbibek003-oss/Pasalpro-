# Milestone 9 — Core operational app

This milestone intentionally combines several small milestones to keep the project moving quickly.

Implemented:
- Real OTP request/verify client flow with development OTP support.
- Authenticated shop selection/creation flow.
- Live dashboard summary from PostgreSQL-backed API.
- Functional customer list + add customer.
- Functional product/stock list + add product.
- Functional POS cart, customer selection, paid amount and sale submission.
- Server-side atomic sale transaction: stock deduction + sale items + Khata credit + audit log.
- Sales history API foundation.
- Receipt and payment modules remain server-backed and ready for provider adapters.

Before production release:
- Replace development OTP with an SMS provider.
- Use secure persistent token storage on device.
- Configure production API URL and TLS.
- Add real eSewa/Khalti signed verification adapters.
- Complete device approval UI, notifications, backups, tests and store signing.
