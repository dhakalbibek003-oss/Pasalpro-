# PasalPro Final Status

This package consolidates the current PasalPro work into one release-candidate source tree.

## Included
- Flutter mobile application shell and core screens
- Backend API foundation
- PostgreSQL migration/schema foundation
- Authentication/session foundation
- Shop/device/role foundations
- Customer, product, stock, sales, khata, payment and receipt foundations
- Security/rate-limit/logout foundations
- Docker local backend setup
- Tests and release documentation

## APK status
No APK is included in this archive. An Android build environment (Flutter SDK + Android SDK/build tools) is required to compile and sign the Flutter project into an installable APK/AAB.

The source is not represented as a completed production deployment until the external service credentials, SMS/OTP provider, payment merchant credentials, production database, and Android signing configuration are supplied and tested.
