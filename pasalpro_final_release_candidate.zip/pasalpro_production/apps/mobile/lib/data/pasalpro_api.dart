import '../core/network/api_client.dart';

class PasalProApi {
  final ApiClient client;
  PasalProApi(this.client);

  Future<Map<String, dynamic>> requestOtp(String phone) => client.post('/api/auth/otp/request', {'phone': phone});
  Future<Map<String, dynamic>> verifyOtp(String phone, String otp) => client.post('/api/auth/otp/verify', {'phone': phone, 'otp': otp});
  Future<Map<String, dynamic>> myShops() => client.get('/api/shops/mine');
  Future<Map<String, dynamic>> createShop({required String name, required String ownerName, required String phone, String? address}) => client.post('/api/shops', {'name': name, 'ownerName': ownerName, 'phone': phone, 'address': address});
  Future<Map<String, dynamic>> health() => client.get('/health');
  Future<Map<String, dynamic>> logout() => client.post('/api/auth/logout', {});
  Future<Map<String, dynamic>> summary(String shopId) => client.get('/api/business/$shopId/summary');
  Future<Map<String, dynamic>> customers(String shopId) => client.get('/api/business/$shopId/customers');
  Future<Map<String, dynamic>> addCustomer(String shopId, String name, String phone) => client.post('/api/business/$shopId/customers', {'name': name, 'phone': phone});
  Future<Map<String, dynamic>> products(String shopId) => client.get('/api/business/$shopId/products');
  Future<Map<String, dynamic>> addProduct(String shopId, {required String name, required double salePrice, double openingQty = 0, String unit = 'pcs'}) => client.post('/api/business/$shopId/products', {'name': name, 'salePrice': salePrice, 'openingQty': openingQty, 'unit': unit});
  Future<Map<String, dynamic>> addStock(String shopId, String productId, double qty) => client.post('/api/business/$shopId/products/$productId/stock', {'qty': qty, 'type': 'PURCHASE'});
  Future<Map<String, dynamic>> customerKhata(String shopId, String customerId) => client.get('/api/business/$shopId/customers/$customerId/khata');
  Future<Map<String, dynamic>> recordPayment(String shopId, String customerId, double amount) => client.post('/api/business/$shopId/customers/$customerId/payment', {'amount': amount});
  Future<Map<String, dynamic>> createSale(String shopId, {String? customerId, required List<Map<String, dynamic>> items, required double paidAmount}) => client.post('/api/business/$shopId/sales', {'customerId': customerId, 'items': items, 'paidAmount': paidAmount});
  Future<Map<String, dynamic>> paymentIntent(String shopId, String intentId) => client.get('/api/payments/$shopId/intents/$intentId');
  Future<Map<String, dynamic>> receipt(String shopId, String saleId) => client.get('/api/receipts/$shopId/$saleId');
}
