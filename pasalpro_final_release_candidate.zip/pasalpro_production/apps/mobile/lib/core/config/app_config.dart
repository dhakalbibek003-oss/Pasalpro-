class AppConfig {
  static const appName = 'PasalPro';
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://localhost:8080');
}
