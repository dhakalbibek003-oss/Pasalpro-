class AppSession {
  String? accessToken;
  String? shopId;
  String? shopName;
  String? role;
  bool get signedIn => accessToken != null;
  void clear() { accessToken = null; shopId = null; shopName = null; role = null; }
}
