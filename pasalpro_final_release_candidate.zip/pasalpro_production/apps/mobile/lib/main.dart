import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/presentation/login_page.dart';
void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const PasalProApp());}
class PasalProApp extends StatelessWidget{const PasalProApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'PasalPro',theme:AppTheme.light(),home:const LoginPage());}
