import 'package:flutter/material.dart';
import '../../../core/network/api_client.dart';
import '../../../core/config/app_config.dart';
import '../../../data/pasalpro_api.dart';
import '../../app/presentation/app_shell.dart';

class ShopGatePage extends StatefulWidget { final String token; const ShopGatePage({super.key,required this.token}); @override State<ShopGatePage> createState()=>_ShopGatePageState(); }
class _ShopGatePageState extends State<ShopGatePage>{
  late final PasalProApi api=PasalProApi(ApiClient(baseUrl:AppConfig.apiBaseUrl,accessToken:widget.token)); List<dynamic> shops=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async { try{final r=await api.myShops();setState(()=>shops=r['shops']??[]);}catch(_){ }finally{setState(()=>loading=false);} }
  void open(dynamic s)=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>AppShell(token:widget.token,shopId:s['id'],shopName:s['name'])));
  Future<void> create() async { final name=TextEditingController(),owner=TextEditingController(),phone=TextEditingController(); final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Create shop'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Shop name')),TextField(controller:owner,decoration:const InputDecoration(labelText:'Owner name')),TextField(controller:phone,decoration:const InputDecoration(labelText:'Phone'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Create'))])); if(ok!=true)return; final r=await api.createShop(name:name.text,ownerName:owner.text,phone:phone.text); if(mounted)open(r['shop']); }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Choose shop')),body:loading?const Center(child:CircularProgressIndicator()):shops.isEmpty?Center(child:FilledButton(onPressed:create,child:const Text('Create your first shop'))):ListView(padding:const EdgeInsets.all(20),children:[...shops.map((s)=>Card(child:ListTile(title:Text(s['name']),subtitle:Text('${s['shop_code']} • ${s['role']}'),trailing:const Icon(Icons.chevron_right),onTap:()=>open(s)))),const SizedBox(height:10),OutlinedButton.icon(onPressed:create,icon:const Icon(Icons.add_business),label:const Text('Add another shop'))]);
}
