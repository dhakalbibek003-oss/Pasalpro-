import 'package:flutter/material.dart';
import '../../dashboard/presentation/dashboard_page.dart';

class ShopOnboardingPage extends StatefulWidget {
  const ShopOnboardingPage({super.key});
  @override State<ShopOnboardingPage> createState() => _ShopOnboardingPageState();
}

class _ShopOnboardingPageState extends State<ShopOnboardingPage> {
  final name = TextEditingController();
  final owner = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();

  @override
  void dispose() {
    name.dispose(); owner.dispose(); phone.dispose(); address.dispose(); super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Create your shop')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Shop name')),
        const SizedBox(height: 12),
        TextField(controller: owner, decoration: const InputDecoration(labelText: 'Owner name')),
        const SizedBox(height: 12),
        TextField(controller: phone, keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'Shop mobile')),
        const SizedBox(height: 12),
        TextField(controller: address, decoration: const InputDecoration(labelText: 'Shop address')),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () => Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => const DashboardPage())),
          child: const Text('Create Shop'),
        ),
      ],
    ),
  );
}
