import 'package:flutter/material.dart';
import '../../../core/network/api_client.dart';
import '../../../core/config/app_config.dart';
import '../../dashboard/presentation/dashboard_page.dart';
import '../../customers/presentation/customers_page.dart';
import '../../stock/presentation/stock_page.dart';
import '../../sales/presentation/sales_page.dart';
import '../../payments/presentation/payments_page.dart';
import '../../receipts/presentation/receipts_page.dart';

class AppShell extends StatefulWidget { final String token,shopId,shopName; const AppShell({super.key,required this.token,required this.shopId,required this.shopName}); @override State<AppShell> createState()=>_AppShellState(); }
class _AppShellState extends State<AppShell>{ int index=0; late final ApiClient client=ApiClient(baseUrl:AppConfig.apiBaseUrl,accessToken:widget.token); late final pages=[DashboardPage(api:client,shopId:widget.shopId,shopName:widget.shopName),SalesPage(api:client,shopId:widget.shopId),CustomersPage(api:client,shopId:widget.shopId),StockPage(api:client,shopId:widget.shopId),PaymentsPage(api:client,shopId:widget.shopId),ReceiptsPage(api:client,shopId:widget.shopId)]; final labels=['Dashboard','Sales','Khata','Stock','Payments','Receipts']; final icons=[Icons.dashboard_outlined,Icons.point_of_sale_outlined,Icons.people_outline,Icons.inventory_2_outlined,Icons.payments_outlined,Icons.receipt_long_outlined]; @override Widget build(BuildContext c)=>Scaffold(body:Row(children:[NavigationRail(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),labelType:NavigationRailLabelType.all,destinations:[for(int i=0;i<labels.length;i++)NavigationRailDestination(icon:Icon(icons[i]),label:Text(labels[i]))]),const VerticalDivider(width:1),Expanded(child:pages[index])]),bottomNavigationBar:MediaQuery.sizeOf(c).width<700?NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:[for(int i=0;i<labels.length;i++)NavigationDestination(icon:Icon(icons[i]),label:labels[i])]):null); }
