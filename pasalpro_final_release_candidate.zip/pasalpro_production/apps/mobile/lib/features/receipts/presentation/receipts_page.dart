import 'package:flutter/material.dart';
import '../../../core/network/api_client.dart';
class ReceiptsPage extends StatelessWidget{final ApiClient api;final String shopId;const ReceiptsPage({super.key,required this.api,required this.shopId});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Receipts')),body:const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('Every completed sale has a server-backed receipt endpoint with items, total, paid amount, Khata and transaction ID.',textAlign:TextAlign.center)));}
