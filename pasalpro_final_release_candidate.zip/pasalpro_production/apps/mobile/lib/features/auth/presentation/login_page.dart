import 'package:flutter/material.dart';
import '../../../core/config/app_config.dart';
import '../../../core/network/api_client.dart';
import '../../../data/pasalpro_api.dart';
import '../../shop/presentation/shop_gate_page.dart';

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final phone=TextEditingController(); final otp=TextEditingController(); bool sent=false,busy=false; String? devOtp; String? error;
  PasalProApi get api=>PasalProApi(ApiClient(baseUrl:AppConfig.apiBaseUrl));
  Future<void> send() async { setState(()=>busy=true); try { final r=await api.requestOtp(phone.text.trim()); setState(()=>{sent=true,devOtp=r['developmentOtp']?.toString(),error=null}); } catch(e){setState(()=>error=e.toString());} finally{setState(()=>busy=false);} }
  Future<void> verify() async { setState(()=>busy=true); try { final r=await api.verifyOtp(phone.text.trim(),otp.text.trim()); final token=r['session']['accessToken'] as String; if(!mounted)return; Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ShopGatePage(token:token))); } catch(e){setState(()=>error=e.toString());} finally{setState(()=>busy=false);} }
  @override void dispose(){phone.dispose();otp.dispose();super.dispose();}
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430),child:Padding(padding:const EdgeInsets.all(24),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('PasalPro',style:TextStyle(fontSize:32,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('Kirana shop management'),const SizedBox(height:24),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Mobile number',hintText:'98XXXXXXXX')),if(sent)...[const SizedBox(height:12),TextField(controller:otp,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:'OTP',helperText:devOtp==null?null:'Development OTP: $devOtp'))],if(error!=null)...[const SizedBox(height:12),Text(error!,style:TextStyle(color:Theme.of(c).colorScheme.error))],const SizedBox(height:18),FilledButton(onPressed:busy?null:(sent?verify:send),child:Text(busy?'Please wait...':(sent?'Verify OTP':'Send OTP'))),if(sent)TextButton(onPressed:busy?null:send,child:const Text('Resend OTP'))])))))));
}
