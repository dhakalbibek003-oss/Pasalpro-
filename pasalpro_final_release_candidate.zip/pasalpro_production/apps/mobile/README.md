# PasalPro Flutter app

Run with Flutter SDK:

```bash
flutter pub get
flutter run
```

Set the API base URL in `lib/core/config/app_config.dart` for the target device.
